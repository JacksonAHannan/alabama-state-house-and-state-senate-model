Alabama 2022 State Legislative Chamber Lower Candidate Race and Gender Data

## RDH Date Retrieval
01/30/24

## Fields:
Field Name         Description                                        
Elect_date         Election Date                                      
Elect_type         Election Type                                      
Office             Legislative Office                                 
District           Legislative District                               
Canc_prim          Binary indicating whether primary election was cancelled
Cand_id            Unique Candidate ID                                
Cand_name          Candidate Name                                     
Party              Political Party                                         
Gender             Candidate Gender                                   
Race_1             Candidate Race                                     
Race_1_Eth         Candidate Ethnicity                                
Race_1_type        Type of Source to Determine Race                   
Race_1_source      Source to Determine Race                           
Race_1_conf        Confidence Level Associated with Race Determination
Race_1_URL         Source URL
Street_add         Street address (if available)
City               City (if available)
State              State name (if available)
Zip                Zip code (if available)
Oth_id_1           Other identities of interest (if available)
Oth_id_2           Other identities of interest (if available)
Notes              Notes from RDH researcher                                         

All instances of Race_2 or Race_3 signal a second or third race category applicable to a candidate.

## Notes on Field Names
Cand_id column generally follows the pattern, adapted from VEST: 
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.*
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

One example is: PSL001RHIL

*To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature and US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
SLDL  - State Legislative Lower

Party Codes Used:
D - Democratic
R - Republican
G - Green
C - Constitution
N - No Party Affiliation
I - Independent

Gender Codes Used:
M - Male
F - Female
O - Other

Race_1, Race_2, Race_3 Codes Used:
AIAN - American Indian or Alaska Native
BLK - Black or African-American
HISP - Hispanic/Latino
NHPI - Native Hawaiian or Other Pacific Islander
WHT - White or Caucasian
MENA - Middle Eastern or Northern African
ASN - Asian
OTH - Other

Race_1_Eth, Race_2_Eth, Race_3_Eth Codes Used:
Uses the exact spelling from the list of possible ethnicities in Appendix F of the US Census PL technical documentation starting on pg. 193 (https://www2.census.gov/programs-surveys/decennial/2020/technical-documentation/complete-tech-docs/summary-file/2020Census_PL94_171Redistricting_StatesTechDoc_English.pdf#page=193)

Race_1_type, Race_2_type, Race_3_type Codes Used:
VF = voter file
WEB = a candidate's website
ORG = membership in a racial or ethnic group caucus or organization, or endorsement or funding by a racial or ethnic group
NEWS = a news article
OTH = anything else

Race_1_source, Race_2_source, Race_3_source Codes Used:	
CAND = race/ethnicity is reported by the candidate
OTH = race/ethnicity is reported by someone else, such as a journalist or organization
GUES = race/ethnicity is assumed based on a photo or other source of information

Race_1_conf, Race_2_conf, Race_3_conf	Codes Used:	
HIGH = high confidence in assuming the race/ethnicity of the person
MED = medium confidence in assuming the race/ethnicity of the person
LOW = low confidence in assuming the race/ethnicity of the person

Oth_id_1; Oth_id_2 Codes Used: 
CHR = Christian
MUS = Muslim
HIN = Hindu
BUD = Buddhist
JUD = Jewish
CATH = Catholic
LES = Lesbian
GAY = Gay
BIS = Bisexual
TRA = Transgender
QUE = Queer
IMM = First generation immigrant
VET = Veteran
INT = Intersex

## Data Collection Notes

Please note that although we produced this file to be as accurate as possible, we may come across additional information in the future which may require us to update this file.

RDH staff logged data according to the notes above. 

Staff searched Google for each candidate's name. Staff used candidates' campaign websites when possible, but some did not have active or accessible websites. In those cases, staff relied on campaign Facebook pages, news articles, Ballotpedia or other sources.

Whenever possible, staff archived their source using the WaybackMachine browser extension to ensure users can access sources even if they are taken offline.

In most cases, candidates did not describe their own race in available online materials. RDH staff relied on journalist descriptions or made guesses based on candidate name and/or appearance.

The list of candidates for this dataset was derived from RDH's processed 2023 Mississippi Primary and General Election Returns. This dataset does not include information on write-in candidates.

## Additional Notes
Please direct questions related to processing this dataset to info@redistrictingdatahub.org.